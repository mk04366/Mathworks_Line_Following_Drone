#ifndef __c1_flightControlSystem_h__
#define __c1_flightControlSystem_h__

/* Forward Declarations */
#ifndef typedef_c1_sFHnVAEfYCbsUaCdnQ39tMD
#define typedef_c1_sFHnVAEfYCbsUaCdnQ39tMD

typedef struct c1_tag_sFHnVAEfYCbsUaCdnQ39tMD c1_sFHnVAEfYCbsUaCdnQ39tMD;

#endif                                 /* typedef_c1_sFHnVAEfYCbsUaCdnQ39tMD */

#ifndef typedef_c1_cell_0
#define typedef_c1_cell_0

typedef struct c1_tag_2iiteIdGaLsc8TaYxgpJoD c1_cell_0;

#endif                                 /* typedef_c1_cell_0 */

#ifndef typedef_c1_cell_1
#define typedef_c1_cell_1

typedef struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE c1_cell_1;

#endif                                 /* typedef_c1_cell_1 */

#ifndef typedef_c1_cell_2
#define typedef_c1_cell_2

typedef struct c1_tag_WYClaNMLzsYbJFiV2mng6F c1_cell_2;

#endif                                 /* typedef_c1_cell_2 */

#ifndef typedef_c1_cell_wrap_3
#define typedef_c1_cell_wrap_3

typedef struct c1_tag_y2anywF90yUI9j7qH5yd3E c1_cell_wrap_3;

#endif                                 /* typedef_c1_cell_wrap_3 */

#ifndef typedef_c1_cell_4
#define typedef_c1_cell_4

typedef struct c1_tag_6CsBRVljdCQyAxGT7eZM3E c1_cell_4;

#endif                                 /* typedef_c1_cell_4 */

#ifndef typedef_c1_cell_wrap_6
#define typedef_c1_cell_wrap_6

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_6;

#endif                                 /* typedef_c1_cell_wrap_6 */

#ifndef typedef_c1_cell_7
#define typedef_c1_cell_7

typedef struct c1_tag_TG9p2ZGDXoo1VFOxFDiXG c1_cell_7;

#endif                                 /* typedef_c1_cell_7 */

#ifndef typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF
#define typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF

typedef struct c1_tag_JWFNkfRUnt2nHgJh2qlbgF c1_s_JWFNkfRUnt2nHgJh2qlbgF;

#endif                                 /* typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF */

#ifndef typedef_c1_s_ynaaIE6q9xznGBkza31TCF
#define typedef_c1_s_ynaaIE6q9xznGBkza31TCF

typedef struct c1_tag_ynaaIE6q9xznGBkza31TCF c1_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* typedef_c1_s_ynaaIE6q9xznGBkza31TCF */

#ifndef typedef_c1_s_HSHOljOSgF7qDZeWd2IfH
#define typedef_c1_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c1_tag_HSHOljOSgF7qDZeWd2IfH c1_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* typedef_c1_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef typedef_c1_s_BrRdqYMft44ulwR1A7rKqF
#define typedef_c1_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c1_tag_BrRdqYMft44ulwR1A7rKqF c1_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* typedef_c1_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH
#define typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH c1_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef typedef_c1_s_xIv9xh4Qt5javKSREWQnWE
#define typedef_c1_s_xIv9xh4Qt5javKSREWQnWE

typedef struct c1_tag_xIv9xh4Qt5javKSREWQnWE c1_s_xIv9xh4Qt5javKSREWQnWE;

#endif                                 /* typedef_c1_s_xIv9xh4Qt5javKSREWQnWE */

/* Type Definitions */
#ifndef struct_c1_tag_sFHnVAEfYCbsUaCdnQ39tMD
#define struct_c1_tag_sFHnVAEfYCbsUaCdnQ39tMD

struct c1_tag_sFHnVAEfYCbsUaCdnQ39tMD
{
  char_T method[6];
};

#endif                                 /* struct_c1_tag_sFHnVAEfYCbsUaCdnQ39tMD */

#ifndef typedef_c1_sFHnVAEfYCbsUaCdnQ39tMD
#define typedef_c1_sFHnVAEfYCbsUaCdnQ39tMD

typedef struct c1_tag_sFHnVAEfYCbsUaCdnQ39tMD c1_sFHnVAEfYCbsUaCdnQ39tMD;

#endif                                 /* typedef_c1_sFHnVAEfYCbsUaCdnQ39tMD */

#ifndef struct_c1_tag_2iiteIdGaLsc8TaYxgpJoD
#define struct_c1_tag_2iiteIdGaLsc8TaYxgpJoD

struct c1_tag_2iiteIdGaLsc8TaYxgpJoD
{
  char_T f1[5];
  char_T f2[6];
  char_T f3[6];
  char_T f4[4];
  char_T f5[5];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
};

#endif                                 /* struct_c1_tag_2iiteIdGaLsc8TaYxgpJoD */

#ifndef typedef_c1_cell_0
#define typedef_c1_cell_0

typedef struct c1_tag_2iiteIdGaLsc8TaYxgpJoD c1_cell_0;

#endif                                 /* typedef_c1_cell_0 */

#ifndef struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE
#define struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE

struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[2];
};

#endif                                 /* struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE */

#ifndef typedef_c1_cell_1
#define typedef_c1_cell_1

typedef struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE c1_cell_1;

#endif                                 /* typedef_c1_cell_1 */

#ifndef struct_c1_tag_WYClaNMLzsYbJFiV2mng6F
#define struct_c1_tag_WYClaNMLzsYbJFiV2mng6F

struct c1_tag_WYClaNMLzsYbJFiV2mng6F
{
  char_T f1[6];
  char_T f2[5];
  char_T f3[4];
  char_T f4[7];
  char_T f5[6];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[5];
};

#endif                                 /* struct_c1_tag_WYClaNMLzsYbJFiV2mng6F */

#ifndef typedef_c1_cell_2
#define typedef_c1_cell_2

typedef struct c1_tag_WYClaNMLzsYbJFiV2mng6F c1_cell_2;

#endif                                 /* typedef_c1_cell_2 */

#ifndef struct_c1_tag_y2anywF90yUI9j7qH5yd3E
#define struct_c1_tag_y2anywF90yUI9j7qH5yd3E

struct c1_tag_y2anywF90yUI9j7qH5yd3E
{
  char_T f1[9];
};

#endif                                 /* struct_c1_tag_y2anywF90yUI9j7qH5yd3E */

#ifndef typedef_c1_cell_wrap_3
#define typedef_c1_cell_wrap_3

typedef struct c1_tag_y2anywF90yUI9j7qH5yd3E c1_cell_wrap_3;

#endif                                 /* typedef_c1_cell_wrap_3 */

#ifndef struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E
#define struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E

struct c1_tag_6CsBRVljdCQyAxGT7eZM3E
{
  char_T f1[7];
  char_T f2[7];
  char_T f3[5];
  char_T f4[6];
  char_T f5[7];
  char_T f6[8];
};

#endif                                 /* struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E */

#ifndef typedef_c1_cell_4
#define typedef_c1_cell_4

typedef struct c1_tag_6CsBRVljdCQyAxGT7eZM3E c1_cell_4;

#endif                                 /* typedef_c1_cell_4 */

#ifndef struct_c1_tag_L5JvjW1A13FyCQi5N783sB
#define struct_c1_tag_L5JvjW1A13FyCQi5N783sB

struct c1_tag_L5JvjW1A13FyCQi5N783sB
{
  char_T f1[7];
};

#endif                                 /* struct_c1_tag_L5JvjW1A13FyCQi5N783sB */

#ifndef typedef_c1_cell_wrap_6
#define typedef_c1_cell_wrap_6

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_6;

#endif                                 /* typedef_c1_cell_wrap_6 */

#ifndef struct_c1_tag_TG9p2ZGDXoo1VFOxFDiXG
#define struct_c1_tag_TG9p2ZGDXoo1VFOxFDiXG

struct c1_tag_TG9p2ZGDXoo1VFOxFDiXG
{
  char_T f1[6];
  char_T f2[4];
  char_T f3[6];
  char_T f4[9];
  char_T f5[11];
};

#endif                                 /* struct_c1_tag_TG9p2ZGDXoo1VFOxFDiXG */

#ifndef typedef_c1_cell_7
#define typedef_c1_cell_7

typedef struct c1_tag_TG9p2ZGDXoo1VFOxFDiXG c1_cell_7;

#endif                                 /* typedef_c1_cell_7 */

#ifndef struct_c1_tag_JWFNkfRUnt2nHgJh2qlbgF
#define struct_c1_tag_JWFNkfRUnt2nHgJh2qlbgF

struct c1_tag_JWFNkfRUnt2nHgJh2qlbgF
{
  c1_cell_0 _data;
};

#endif                                 /* struct_c1_tag_JWFNkfRUnt2nHgJh2qlbgF */

#ifndef typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF
#define typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF

typedef struct c1_tag_JWFNkfRUnt2nHgJh2qlbgF c1_s_JWFNkfRUnt2nHgJh2qlbgF;

#endif                                 /* typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF */

#ifndef struct_c1_tag_ynaaIE6q9xznGBkza31TCF
#define struct_c1_tag_ynaaIE6q9xznGBkza31TCF

struct c1_tag_ynaaIE6q9xznGBkza31TCF
{
  c1_cell_1 _data;
};

#endif                                 /* struct_c1_tag_ynaaIE6q9xznGBkza31TCF */

#ifndef typedef_c1_s_ynaaIE6q9xznGBkza31TCF
#define typedef_c1_s_ynaaIE6q9xznGBkza31TCF

typedef struct c1_tag_ynaaIE6q9xznGBkza31TCF c1_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* typedef_c1_s_ynaaIE6q9xznGBkza31TCF */

#ifndef struct_c1_tag_HSHOljOSgF7qDZeWd2IfH
#define struct_c1_tag_HSHOljOSgF7qDZeWd2IfH

struct c1_tag_HSHOljOSgF7qDZeWd2IfH
{
  c1_cell_2 _data;
};

#endif                                 /* struct_c1_tag_HSHOljOSgF7qDZeWd2IfH */

#ifndef typedef_c1_s_HSHOljOSgF7qDZeWd2IfH
#define typedef_c1_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c1_tag_HSHOljOSgF7qDZeWd2IfH c1_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* typedef_c1_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef struct_c1_tag_BrRdqYMft44ulwR1A7rKqF
#define struct_c1_tag_BrRdqYMft44ulwR1A7rKqF

struct c1_tag_BrRdqYMft44ulwR1A7rKqF
{
  c1_cell_wrap_3 _data;
};

#endif                                 /* struct_c1_tag_BrRdqYMft44ulwR1A7rKqF */

#ifndef typedef_c1_s_BrRdqYMft44ulwR1A7rKqF
#define typedef_c1_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c1_tag_BrRdqYMft44ulwR1A7rKqF c1_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* typedef_c1_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH
#define struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH

struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH
{
  c1_cell_4 _data;
};

#endif                                 /* struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH
#define typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH c1_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef struct_c1_tag_HOps0FrfA6RiWumqewPwZD
#define struct_c1_tag_HOps0FrfA6RiWumqewPwZD

struct c1_tag_HOps0FrfA6RiWumqewPwZD
{
  c1_cell_wrap_6 _data;
};

#endif                                 /* struct_c1_tag_HOps0FrfA6RiWumqewPwZD */

#ifndef typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef struct_c1_tag_xIv9xh4Qt5javKSREWQnWE
#define struct_c1_tag_xIv9xh4Qt5javKSREWQnWE

struct c1_tag_xIv9xh4Qt5javKSREWQnWE
{
  c1_cell_7 _data;
};

#endif                                 /* struct_c1_tag_xIv9xh4Qt5javKSREWQnWE */

#ifndef typedef_c1_s_xIv9xh4Qt5javKSREWQnWE
#define typedef_c1_s_xIv9xh4Qt5javKSREWQnWE

typedef struct c1_tag_xIv9xh4Qt5javKSREWQnWE c1_s_xIv9xh4Qt5javKSREWQnWE;

#endif                                 /* typedef_c1_s_xIv9xh4Qt5javKSREWQnWE */

#ifndef typedef_SFc1_flightControlSystemInstanceStruct
#define typedef_SFc1_flightControlSystemInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c1_sfEvent;
  boolean_T c1_doneDoubleBufferReInit;
  uint8_T c1_is_active_c1_flightControlSystem;
  uint8_T c1_JITStateAnimation[1];
  uint8_T c1_JITTransitionAnimation[1];
  int32_T c1_IsDebuggerActive;
  int32_T c1_IsSequenceViewerPresent;
  int32_T c1_SequenceViewerOptimization;
  int32_T c1_IsHeatMapPresent;
  void *c1_RuntimeVar;
  uint32_T c1_mlFcnLineNumber;
  void *c1_fcnDataPtrs[17];
  char_T *c1_dataNames[17];
  uint32_T c1_numFcnVars;
  uint32_T c1_ssIds[17];
  uint32_T c1_statuses[17];
  void *c1_outMexFcns[17];
  void *c1_inMexFcns[17];
  CovrtStateflowInstance *c1_covrtInstance;
  void *c1_fEmlrtCtx;
  uint8_T (*c1_in)[19200];
  real_T *c1_ang;
  boolean_T (*c1_b)[19200];
  real_T *c1_x_new;
  real_T *c1_y_new;
} SFc1_flightControlSystemInstanceStruct;

#endif                                 /* typedef_SFc1_flightControlSystemInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_flightControlSystem_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c1_flightControlSystem_get_check_sum(mxArray *plhs[]);
extern void c1_flightControlSystem_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
